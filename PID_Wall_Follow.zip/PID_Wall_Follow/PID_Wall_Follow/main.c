// Lab21_OPT3101_TestMain.c
//*****************************************************************************
// Lab21 main for Robot with OPT3101 time of flight sensor
// MSP432 with RSLK Max and OPT3101
// Daniel and Jonathan Valvano
// July 7, 2020
//****************************************************************************
/* This example accompanies the book
   "Embedded Systems: Introduction to Robotics,
   Jonathan W. Valvano, ISBN: 9781074544300, copyright (c) 2020
 For more information about my classes, my research, and my books, see
 http://users.ece.utexas.edu/~valvano/

Simplified BSD License (FreeBSD License)
Copyright (c) 2020, Jonathan Valvano, All rights reserved.

Redistribution and use in source and binary forms, with or without modification,
are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright notice,
   this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright notice,
   this list of conditions and the following disclaimer in the documentation
   and/or other materials provided with the distribution.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED
AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY,
OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE
USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

The views and conclusions contained in the software and documentation are
those of the authors and should not be interpreted as representing official
policies, either expressed or implied, of the FreeBSD Project.
*/
// see opt3101.h for OPT3101 hardware connections
// see Nokia5110.h LCD hardware connections
// see SSD1306.h for OLED hardware connections
// see UART0.h for UART0 hardware connections

#include <stdbool.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <stdio.h>
#include "inc/SysTickInts.h"
#include "inc/Bump.h"
#include "inc/Clock.h"
#include "inc/CortexM.h"
#include "inc/I2CB1.h"
#include "inc/LPF.h"
#include "inc/LaunchPad.h"
#include "inc/Motor.h"
#include "inc/opt3101.h"
#include "inc/UART1.h"
#include "msp.h"
// #include "inc/SSD1306.h"
#include "MQTTClient.h"
#include "driverlib.h"
#include "inc/FFT.h"
#include "simplelink.h"
#include "sl_common.h"

/*
 * Values for below macros shall be modified per the access-point's (AP) properties
 * SimpleLink device will connect to following AP when the application is executed
 */
#define SSID_NAME "ECE DESIGN LAB 2.4"     /* Access point name to connect to. */
#define SEC_TYPE SL_SEC_TYPE_WPA_WPA2   /* Security type of the Access piont */
#define PASSKEY "ecedesignlab12345"           /* Password in case of secure AP */
#define PASSKEY_LEN pal_Strlen(PASSKEY) /* Password length in case of secure AP */

/*
 * MQTT server and topic properties that shall be modified per application
 */
#define MQTT_BROKER_SERVER "174.181.9.199"
#define SUBSCRIBE_TOPIC "Test_Topic"
#define PUBLISH_TOPIC "Test_Pub"

// MQTT message buffer size
#define BUFF_SIZE 32

#define APPLICATION_VERSION "1.0.0"

#define MCLK_FREQUENCY 48000000
// #define PWM_PERIOD 255

#define SL_STOP_TIMEOUT 0xFF

#define SMALL_BUF 32
#define MAX_SEND_BUF_SIZE 512
#define MAX_SEND_RCV_SIZE 1024

#define _USE_CLI_

//#define USEUART

#ifdef USEUART
// this batch configures for UART link to PC
#include "inc/UART0.h"
void UartSetCur(uint8_t newX, uint8_t newY) {
    if (newX == 6) {
        UART0_OutString("\n\rTxChannel= ");
        UART0_OutUDec(newY - 1);
        UART0_OutString(" Distance= ");
    } else {
        UART0_OutString("\n\r");
    }
}
// void UartClear(void){UART0_OutString("\n\r");};
#define Init UART0_Init
#define Clear UartClear
#define SetCursor UartSetCur
#define OutString UART0_OutString
#define OutChar UART0_OutChar
#define OutUDec UART0_OutUDec
#define OutSDec UART0_OutSDec
#endif

volatile bool rightMode = false;
volatile uint8_t reflectanceResult;
uint32_t numCollisions = 0;
uint8_t uartMessage;

uint32_t Distances[3];
uint32_t FilteredDistances[3];
uint32_t Amplitudes[3];
uint32_t Noises[3];
uint32_t TxChannel;
uint32_t StartTime;
uint32_t TimeToConvert;  // in msec

bool pollDistanceSensor(void) {
    if (OPT3101_CheckDistanceSensor()) {
        TxChannel = OPT3101_GetMeasurement(Distances, Amplitudes);
        return true;
    }
    return false;
}


// calibrated for 500mm track
// right is raw sensor data from right sensor
// return calibrated distance from center of Robot to right wall
int32_t Right(int32_t right) {
    return (right * (59 * right + 7305) + 2348974) / 32768;
}
// left is raw sensor data from left sensor
// return calibrated distance from center of Robot to left wall
int32_t Left(int32_t left) {
    return (1247 * left) / 2048 + 22;
}

#define N 1024
uint32_t Data[N];
#define M 1024
uint16_t Histogram[M];
uint32_t Sum;       // sum of data
uint32_t Sum2;      // sum of (data-average)^2
uint32_t Average;   // average of data = sum/N
uint32_t Variance;  // =sum2/(N-1)
uint32_t Sigma;     // standard deviation = sqrt(Variance)

// assumes track is 500mm
int32_t Mode = 0;  // 0 stop, 1 run
int32_t Error;
int32_t Ki = 1;  // integral controller gain
int32_t Kp = 3;  // proportional controller gain //was 4
int32_t UR, UL;  // PWM duty 0 to 14,998

#define TOOCLOSE 200                                  // was 200
#define DESIRED 150                                   // was 250
int32_t SetPoint = 250;                               // mm //was 250
int32_t LeftDistance, CenterDistance, RightDistance;  // mm
int32_t LeftAmplitude;
int32_t RightAmplitude;
#define TOOFAR 400                                    // was 400

#define PWMNOMINAL 3000  // was 2500
#define SWING 1500       // was 1000
#define SWING_STRONG 3000
#define PWMMIN (PWMNOMINAL - SWING)
#define PWMMAX (PWMNOMINAL + SWING)

int32_t range = 25;


void Controller(void) {  // runs at 100 Hz
    if (Mode) {



        if (CenterDistance < 300) {  // Obstacle directly in front
            if (LeftDistance == RightDistance) {
                if (LeftAmplitude > RightAmplitude) {
                    UR = PWMNOMINAL - SWING_STRONG;
                    UL = UL + Ki * Error;
                    UL = PWMNOMINAL + SWING_STRONG;
                    UL = UL + Ki * Error;
//                    mqttPubStats("Obstacle in front... Turning left from amplitude", "turns");
                }
                else {
                    UR = PWMNOMINAL + SWING_STRONG;
                    UR = UR + Ki * Error;
                    UL = PWMNOMINAL - SWING_STRONG;
                    UL = UL + Ki * Error;
//                    mqttPubStats("Obstacle in front... Turning right from amplitude", "turns");
                }
            }
            else if (CenterDistance >= (RightDistance - range) || CenterDistance <= (RightDistance + range)) {
                // More space on the left, turn left
                UR = PWMNOMINAL + SWING_STRONG;
                UR = UR + Ki * Error;
                UL = PWMNOMINAL - SWING_STRONG;
                UL = UL + Ki * Error;
//                mqttPubStats("Obstacle in front... Turning left to available space", "turns");
            }
            else if(CenterDistance >= (LeftDistance - range) || CenterDistance <= (LeftDistance - range) ) {
                // More space on the right, turn right
                UR = PWMNOMINAL - SWING_STRONG;
                UL = UL + Ki * Error;
                UL = PWMNOMINAL + SWING_STRONG;
                UL = UL + Ki * Error;
//                mqttPubStats("Obstacle in front... Turning right to available space", "turns");
            }
            if (LeftDistance > RightDistance) {
                // Turn left
                UR = PWMNOMINAL + SWING;
                UL = PWMNOMINAL - SWING;
            } else {
                // Turn right
                UR = PWMNOMINAL - SWING;
                UL = PWMNOMINAL + SWING;
            }
            Motor_Forward(UL, UR);
            return;  // Skip rest of control loop
        }


        //new
        if ((LeftDistance < DESIRED) && (RightDistance < DESIRED)) {
            SetPoint = (LeftDistance + RightDistance) / 2;
//            mqttPubStats("Tighter space detected...", "turns");
        } else {
            SetPoint = DESIRED;
        }
        if (LeftDistance < RightDistance) {
            Error = LeftDistance - SetPoint;
        } else {
            Error = SetPoint - RightDistance;
        }
        //new
        if ((LeftDistance > DESIRED) && (RightDistance > DESIRED)) {
            SetPoint = (LeftDistance + RightDistance) / 2;
//            mqttPubStats("Wider space detected...", "turns");
        } else {
            SetPoint = DESIRED;
        }
        if (LeftDistance < RightDistance) {
            Error = LeftDistance - SetPoint;
        } else {
            Error = SetPoint - RightDistance;
        }
        //   UR = UR + Ki*Error;      // adjust right motor
        UR = PWMNOMINAL + Kp * Error;                            // proportional control
        UR = UR + Ki * Error;                                    // integral control
        UL = PWMNOMINAL - Kp * Error;                            // proportional control
        UL = UL + Ki * Error;                                    // integral control
        if (UR < (PWMNOMINAL - SWING)) UR = PWMNOMINAL - SWING;  // 3,000 to 7,000
        if (UR > (PWMNOMINAL + SWING)) UR = PWMNOMINAL + SWING;
        if (UL < (PWMNOMINAL - SWING)) UL = PWMNOMINAL - SWING;  // 3,000 to 7,000
        if (UL > (PWMNOMINAL + SWING)) UL = PWMNOMINAL + SWING;
//        mqttPubStats("Making default turn decisions...", "turns");
        Motor_Forward(UL, UR);
    }
}

void Controller_Right(void) {  // runs at 100 Hz
    if (Mode) {
        if ((RightDistance > DESIRED)) {
            SetPoint = (RightDistance) / 2;
        } else {
            SetPoint = DESIRED;
        }

        Error = SetPoint - RightDistance;
        UR = PWMNOMINAL + Kp * Error;                            // proportional control
        UR = UR + Ki * Error;                                    // adjust right motor
        UL = PWMNOMINAL - Kp * Error;                            // proportional control

        if (UR < (PWMNOMINAL - SWING)) UR = PWMNOMINAL - SWING;  // 3,000 to 7,000
        if (UR > (PWMNOMINAL + SWING)) UR = PWMNOMINAL + SWING;
        if (UL < (PWMNOMINAL - SWING)) UL = PWMNOMINAL - SWING;  // 3,000 to 7,000
        if (UL > (PWMNOMINAL + SWING)) UL = PWMNOMINAL + SWING;


        if ((RightDistance < 150) && (CenterDistance < 250)) {
            UL = 0;
            UR = PWMNOMINAL;
        }

        Motor_Forward(UL, UR);
    }
    else {
        Motor_Stop();
    }
}

void Controller_Left(void) {  // runs at 100 Hz
    if (Mode) {
        if ((LeftDistance > DESIRED)) {
            SetPoint = (LeftDistance) / 2;
        } else {
            SetPoint = DESIRED;
        }

        Error = SetPoint - LeftDistance;
        UL = PWMNOMINAL + Kp * Error;                            // proportional control
        UL = UL + Ki * Error;                                    // adjust left motor
        UR = PWMNOMINAL - Kp * Error;                            // proportional control

        if (UR < (PWMNOMINAL - SWING)) UR = PWMNOMINAL - SWING;  // 3,000 to 7,000
        if (UR > (PWMNOMINAL + SWING)) UR = PWMNOMINAL + SWING;
        if (UL < (PWMNOMINAL - SWING)) UL = PWMNOMINAL - SWING;  // 3,000 to 7,000
        if (UL > (PWMNOMINAL + SWING)) UL = PWMNOMINAL + SWING;


        if ((LeftDistance < 150) && (CenterDistance < 250)) {
            UR = 0;
            UL = PWMNOMINAL;
        }

        Motor_Forward(UL, UR);
    }
    else {
        Motor_Stop();
    }
}

void Pause(void) {
    int i;
    while (Bump_Read()) {  // wait for release
        Clock_Delay1ms(200);
        LaunchPad_Output(0);  // off
        Clock_Delay1ms(200);
        LaunchPad_Output(1);  // red
    }
    while (Bump_Read() == 0) {  // wait for touch
        Clock_Delay1ms(100);
        LaunchPad_Output(0);  // off
        Clock_Delay1ms(100);
        LaunchPad_Output(3);  // red/green
    }
    while (Bump_Read()) {  // wait for release
        Clock_Delay1ms(100);
        LaunchPad_Output(0);  // off
        Clock_Delay1ms(100);
        LaunchPad_Output(4);  // blue
    }
    for (i = 1000; i > 100; i = i - 200) {
        Clock_Delay1ms(i);
        LaunchPad_Output(0);  // off
        Clock_Delay1ms(i);
        LaunchPad_Output(2);  // green
    }
    // restart Jacki
    UR = UL = PWMNOMINAL;  // reset parameters
    Mode = 1;
}

/* Application specific status/error codes */
typedef enum {
    DEVICE_NOT_IN_STATION_MODE = -0x7D0, /* Choosing this number to avoid overlap with host-driver's error codes */
    HTTP_SEND_ERROR = DEVICE_NOT_IN_STATION_MODE - 1,
    HTTP_RECV_ERROR = HTTP_SEND_ERROR - 1,
    HTTP_INVALID_RESPONSE = HTTP_RECV_ERROR - 1,
    STATUS_CODE_MAX = -0xBB8
} e_AppStatusCodes;

#define min(X, Y) ((X) < (Y) ? (X) : (Y))

/*
 * GLOBAL VARIABLES -- Start
 */
/* Button debounce state variables */
volatile unsigned int S1buttonDebounce = 0;
volatile unsigned int S2buttonDebounce = 0;
volatile int publishID = 0;

unsigned char macAddressVal[SL_MAC_ADDR_LEN];
unsigned char macAddressLen = SL_MAC_ADDR_LEN;

char macStr[18];   // Formatted MAC Address String
char uniqueID[9];  // Unique ID generated from TLV RAND NUM and MAC Address

Network n;
Client hMQTTClient;  // MQTT Client

_u32 g_Status = 0;
struct {
    _u8 Recvbuff[MAX_SEND_RCV_SIZE];
    _u8 SendBuff[MAX_SEND_BUF_SIZE];

    _u8 HostName[SMALL_BUF];
    _u8 CityName[SMALL_BUF];

    _u32 DestinationIP;
    _i16 SockID;
} g_AppData;

/* Port mapper configuration register */
const uint8_t port_mapping[] =
    {
        // Port P2:
        // PM_TA0CCR1A, PM_TA0CCR2A, PM_TA0CCR3A, PM_NONE, PM_TA1CCR1A, PM_NONE, PM_NONE, PM_NONE
        PM_TA0CCR1A, PM_TA0CCR2A, PM_TA0CCR3A, PM_NONE, PM_TA1CCR1A, PM_NONE, PM_NONE, PM_NONE};

/* TimerA UpMode Configuration Parameter */
const Timer_A_UpModeConfig upConfig =
    {
        TIMER_A_CLOCKSOURCE_SMCLK,           // SMCLK Clock Source
        TIMER_A_CLOCKSOURCE_DIVIDER_8,       // SMCLK/8 = 6MHz
        90000,                               // 15ms debounce period
        TIMER_A_TAIE_INTERRUPT_DISABLE,      // Disable Timer interrupt
        TIMER_A_CCIE_CCR0_INTERRUPT_ENABLE,  // Enable CCR0 interrupt
        TIMER_A_DO_CLEAR                     // Clear value
};

/*
 * GLOBAL VARIABLES -- End
 */

/*
 * STATIC FUNCTION DEFINITIONS -- Start
 */
static _i32 establishConnectionWithAP();
static _i32 configureSimpleLinkToDefaultState();
static _i32 initializeAppVariables();
static void displayBanner();
static void messageArrived(MessageData *);
static void generateUniqueID();

/*
 * STATIC FUNCTION DEFINITIONS -- End
 */


void mqttPubStats(char* statMsg, char* topic) {
    int rc = 0;
    MQTTMessage msg;
    msg.dup = 0;
    msg.id = 0;
    msg.payload = statMsg;
    msg.payloadlen = 32;
    msg.qos = QOS0;
    msg.retained = 0;
    rc = MQTTPublish(&hMQTTClient, topic, &msg);

    if (rc != 0) {
        CLI_Write(" Failed to publish unique ID to MQTT broker \n\r");
        LOOP_FOREVER();
    }
    //CLI_Write(" Published unique ID successfully \n\r");
}


int main(void) {  // wallFollow wall following implementation
    char strOut[50];
    char FilDisTx[20];
    char AmpTx[20];
    char SetPnt[20];
    char Err[20];
    char ULstr[20];
    char URstr[20];
    int i = 0;
    uint32_t channel = 1;
    DisableInterrupts();
    Clock_Init48MHz();
    _i32 retVal = -1;

    retVal = initializeAppVariables();
    ASSERT_ON_ERROR(retVal);

    /* Stop WDT and initialize the system-clock of the MCU */
    stopWDT();
    initClk();

    MAP_GPIO_setAsPeripheralModuleFunctionOutputPin(GPIO_PORT_P2,
            GPIO_PIN0 | GPIO_PIN1 | GPIO_PIN2, GPIO_PRIMARY_MODULE_FUNCTION);

    GPIO_setAsInputPinWithPullUpResistor(GPIO_PORT_P1, GPIO_PIN1 | GPIO_PIN4);
    GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN1 | GPIO_PIN4);
    GPIO_enableInterrupt(GPIO_PORT_P1, GPIO_PIN1 | GPIO_PIN4);
    GPIO_interruptEdgeSelect(GPIO_PORT_P1, GPIO_PIN1 | GPIO_PIN4, GPIO_HIGH_TO_LOW_TRANSITION);
    GPIO_clearInterruptFlag(GPIO_PORT_P1, GPIO_PIN1 | GPIO_PIN4);

    GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0);
    GPIO_setAsOutputPin(GPIO_PORT_P1, GPIO_PIN0);

    TA0CTL = 0;

    P2->SEL0 &= ~(0x07);  // Clear the peripheral function selection for Timer A0 pins (P2.0, P2.1, P2.2)
    P2->SEL1 &= ~(0x07);  // Clear the peripheral function selection for Timer A0 pins
    P2->DIR &= ~(0x07);   // Set pins as inputs or outputs (depending on your requirement)

    TA0CCTL1 &= ~CCIE;  // Disable interrupt for CCR1 (if enabled)
    TA0CCTL2 &= ~CCIE;  // Disable interrupt for CCR2 (if enabled)
    TA0CCTL3 &= ~CCIE;  // Disable interrupt for CCR3 (if enabled)
    TA0CCTL0 &= ~CCIE;  // Disable interrupt for CCR0 (if enabled)

    Timer_A_configureUpMode(TIMER_A1_BASE, &upConfig);

    Interrupt_enableInterrupt(INT_TA1_0);
    Interrupt_enableInterrupt(INT_PORT1);
    Interrupt_enableMaster();

    /* Configure command line interface */
    CLI_Configure();
    CLI_Write("CLI Configured\r\n");
    displayBanner();

    retVal = configureSimpleLinkToDefaultState();
    if (retVal < 0) {
        if (DEVICE_NOT_IN_STATION_MODE == retVal)
            CLI_Write(" Failed to configure the device in its default state \n\r");

        LOOP_FOREVER();
    }

    CLI_Write(" Device is configured in default state \n\r");

    /*
     * Assumption is that the device is configured in station mode already
     * and it is in its default state
     */
    retVal = sl_Start(0, 0, 0);
    if ((retVal < 0) ||
        (ROLE_STA != retVal)) {
        CLI_Write(" Failed to start the device \n\r");
        LOOP_FOREVER();
    }

    CLI_Write(" Device started as STATION \n\r");

    /* Connecting to WLAN AP */
    retVal = establishConnectionWithAP();
    if (retVal < 0) {
        CLI_Write(" Failed to establish connection w/ an AP \n\r");
        LOOP_FOREVER();
    }

    CLI_Write(" Connection established w/ AP and IP is acquired \n\r");

    // Obtain MAC Address
    sl_NetCfgGet(SL_MAC_ADDRESS_GET, NULL, &macAddressLen, (unsigned char *)macAddressVal);

    // Print MAC Addres to be formatted string
    snprintf(macStr, sizeof(macStr), "%02x:%02x:%02x:%02x:%02x:%02x",
             macAddressVal[0], macAddressVal[1], macAddressVal[2], macAddressVal[3], macAddressVal[4], macAddressVal[5]);

    // Generate 32bit unique ID from TLV Random Number and MAC Address
    generateUniqueID();

    int rc = 0;
    unsigned char buf[100];
    unsigned char readbuf[100];

    NewNetwork(&n);
    rc = ConnectNetwork(&n, MQTT_BROKER_SERVER, 1883);

    if (rc != 0) {
        CLI_Write(" Failed to connect to MQTT broker \n\r");
        LOOP_FOREVER();
    }
    CLI_Write(" Connected to MQTT broker \n\r");

    MQTTClient(&hMQTTClient, &n, 1000, buf, 100, readbuf, 100);
    MQTTPacket_connectData cdata = MQTTPacket_connectData_initializer;
    cdata.MQTTVersion = 3;
    cdata.clientID.cstring = uniqueID;
    rc = MQTTConnect(&hMQTTClient, &cdata);

    if (rc != 0) {
        CLI_Write(" Failed to start MQTT client \n\r");
        LOOP_FOREVER();
    }
    CLI_Write(" Started MQTT client successfully \n\r");

    rc = MQTTSubscribe(&hMQTTClient, SUBSCRIBE_TOPIC, QOS0, messageArrived);

    if (rc != 0) {
        CLI_Write(" Failed to subscribe to /msp/cc3100/demo topic \n\r");
        LOOP_FOREVER();
    }
    CLI_Write(" Subscribed to /msp/cc3100/demo topic \n\r");

    rc = MQTTSubscribe(&hMQTTClient, uniqueID, QOS0, messageArrived);

    if (rc != 0) {
        CLI_Write(" Failed to subscribe to uniqueID topic \n\r");
        LOOP_FOREVER();
    }
    CLI_Write(" Subscribed to uniqueID topic \n\r");

    Bump_Init();
    Motor_Init();
    //UART0_Init();
    //Reflectance_Init();
    LaunchPad_Init(); // built-in switches and LEDs
    LaunchPad_Output(4);

    // initialize and stop
    Mode = 0;
    I2CB1_Init(30);  // baud rate = 12MHz/30=400kHz

    /*

    Init();
    Clear();
    OutString("OPT3101");
    SetCursor(0, 1);
    OutString("L=");
    SetCursor(0, 2);
    OutString("C=");
    SetCursor(0, 3);
    OutString("R=");
    SetCursor(0, 4);
    OutString("Wall follow");
    SetCursor(0, 5);
    OutString("SP=");
    SetCursor(0, 6);
    OutString("Er=");
    SetCursor(0, 7);
    OutString("U =");

    */
    OPT3101_Init();
    OPT3101_Setup();
    OPT3101_CalibrateInternalCrosstalk();
    OPT3101_ArmInterrupts(&TxChannel, Distances, Amplitudes);
    TxChannel = 3;
    OPT3101_StartMeasurementChannel(channel);
    LPF_Init(100, 8);
    LPF_Init2(100, 8);
    LPF_Init3(100, 8);
    UR = UL = PWMNOMINAL;  // initial power
    //Pause();
    EnableInterrupts();
    while (1) {
        rc = MQTTYield(&hMQTTClient, 10);
        if (rc != 0) {
            CLI_Write(" MQTT failed to yield \n\r");
            LOOP_FOREVER();
        }
/*
        uartMessage =  UART0_InCharNonBlocking();
        //LaunchPad_Output(4);
        switch (uartMessage) {
        case 0x01:
            UR = UL = PWMNOMINAL;
            Mode = 1;
            break;
           case 0x02:
           Mode = 0;
       }
*/
        //if (reflectanceResult) {
        //    Mode = 0;
        //}
        uint8_t bumpData;
        bumpData = Bump_Read();
        if (bumpData) {  // collision
            Mode = 0;


            // Stop any current motion.
            Motor_Stop();

            numCollisions++;
            CLI_Write(" Published unique ID successfully \n\r");
            CLI_Write(numCollisions);
            snprintf(strOut, sizeof(strOut), "%u", numCollisions);
            mqttPubStats(strOut, "collisions");

            Clock_Delay1ms(500);
            // Define sensor groups:
            // Right sensors: Bump2, Bump1, Bump0 (bits BIT2, BIT1, BIT0)
            // Left sensors: Bump5, Bump4, Bump3 (bits BIT5, BIT4, BIT3)
            uint8_t leftSensors = bumpData & (BIT3 | BIT4 | BIT5);
            uint8_t rightSensors = bumpData & (BIT2 | BIT1 | BIT0);

            // Count active sensors on each side.
            int leftCount = 0, rightCount = 0;
            if (leftSensors & BIT5) leftCount++;
            if (leftSensors & BIT4) leftCount++;
            if (leftSensors & BIT3) leftCount++;
            if (rightSensors & BIT0) rightCount++;
            if (rightSensors & BIT1) rightCount++;
            if (rightSensors & BIT2) rightCount++;

            // Advanced decision logic:
            if (leftCount > 0 || rightCount > 0) {
                // Center collision: both sides are impacted.
                // First, reverse to create space.
                Motor_Backward(3000, 3000);
                Clock_Delay1ms(1000);
                // Then choose a turn direction:
                // Turn toward the side with fewer sensors activated.
                if (leftCount > rightCount) {
                    Motor_Right(3000,3000);
                    Clock_Delay1ms(1000);
                } else if (rightCount > leftCount) {
                    Motor_Left(3000,3000);
                   Clock_Delay1ms(1000);
                } else {
                    // If equal, use a default strategy (here, turning left).
                    Motor_Left(3000,3000);
                    Clock_Delay1ms(1000);
                }
            } else if (leftCount > 0) {
                // Collision detected only on the left side:
                // Turn right to avoid the obstacle.
                Motor_Right(3000,3000);
                Clock_Delay1ms(1000);
            } else if (rightCount > 0) {
                // Collision detected only on the right side:
                // Turn left to avoid the obstacle.
                Motor_Left(3000,3000);
                Clock_Delay1ms(1000);
            } else {
                // For any ambiguous or minor sensor activation, consider a small reverse.
                Motor_Backward(3000, 3000);
                Clock_Delay1ms(1000);
            }
            Mode = 1;
            //Pause();
        }


        if (TxChannel <= 2) {  // 0,1,2 means new data
            if (TxChannel == 0) {
                if (Amplitudes[0] > 1000) {
                    LeftDistance = FilteredDistances[0] = Left(LPF_Calc(Distances[0]));
                } else {
                    LeftDistance = FilteredDistances[0] = 500;
                }
                LeftAmplitude = Amplitudes[0];
            } else if (TxChannel == 1) {
                if (Amplitudes[1] > 1000) {
                    CenterDistance = FilteredDistances[1] = LPF_Calc2(Distances[1]);
                } else {
                    CenterDistance = FilteredDistances[1] = 500;
                }
            } else {
                if (Amplitudes[2] > 1000) {
                    RightDistance = FilteredDistances[2] = Right(LPF_Calc3(Distances[2]));
                } else {
                    RightDistance = FilteredDistances[2] = 500;
                }
                RightAmplitude = Amplitudes[2];
            }
            // SetCursor(2, TxChannel+1);
            // OutUDec(FilteredDistances[TxChannel]); OutChar(','); OutUDec(Amplitudes[TxChannel]);


            /*
            snprintf(FilDisTx, sizeof(FilDisTx), "%u", FilteredDistances[TxChannel]);
            //CLI_Write(FilDisTx);
            //CLI_Write(",");
            snprintf(AmpTx, sizeof(AmpTx), "%u", Amplitudes[TxChannel]);
            //CLI_Write(AmpTx);
            //CLI_Write("\r\n");
            snprintf(strOut, sizeof(strOut), "%s,%s", FilDisTx, AmpTx);
            mqttPubStats(strOut, "FilDis_Amp");
            */

            //snprintf(FilDisTx, sizeof(FilDisTx), "%u", FilteredDistances[TxChannel]);
            //snprintf(AmpTx, sizeof(AmpTx), "%u", Amplitudes[TxChannel]);
            //snprintf(strOut, sizeof(strOut), "%s,%s", FilDisTx, AmpTx);



            // Decide the topic name based on TxChannel


            snprintf(strOut, sizeof(strOut), "%u", FilteredDistances[TxChannel]);

            const char* topic;
            if (TxChannel == 0) {
                topic = "left";
            } else if (TxChannel == 1) {
                topic = "center";
            } else {
                topic = "right";
            }

            // Publish to the topic
            mqttPubStats(strOut, topic);


            TxChannel = 3;  // 3 means no data
            channel = (channel + 1) % 3;
            OPT3101_StartMeasurementChannel(channel);
            i = i + 1;
        }
        if (rightMode) {
            Controller_Right();
        } else {
            Controller_Left();
        }
        if (i >= 100) {
            i = 0;
            /*
            snprintf(SetPnt, sizeof(SetPnt), "%d", SetPoint);
            mqttPubStats(SetPnt, "SetPoint");

            snprintf(Err, sizeof(Err), "%d", Error);
            mqttPubStats(Err, "Error");

            snprintf(ULstr, sizeof(ULstr), "%d", UL);

            snprintf(URstr, sizeof(URstr), "%d", UR);

            snprintf(strOut, sizeof(strOut), "%s,%s", ULstr, URstr);
            mqttPubStats(strOut, "UL_UR");
            */
        }

        if (publishID) {
            int rc = 0;
            MQTTMessage msg;
            msg.dup = 0;
            msg.id = 0;
            msg.payload = uniqueID;
            msg.payloadlen = 8;
            msg.qos = QOS0;
            msg.retained = 0;
            rc = MQTTPublish(&hMQTTClient, PUBLISH_TOPIC, &msg);

            if (rc != 0) {
                CLI_Write(" Failed to publish unique ID to MQTT broker \n\r");
                LOOP_FOREVER();
            }
            CLI_Write(" Published unique ID successfully \n\r");

            publishID = 0;
        }

        WaitForInterrupt();
    }

}
// MSP432 memory limited to q=11, N=2048
#define q 8         /* for 2^8 points */
#define NN (1 << q) /* 256-point FFT, iFFT */
complex_t a[NN], scratch[NN];
uint32_t PlotOffset, PlotData;

/*
 * ASYNCHRONOUS EVENT HANDLERS -- Start
 */

/*!
    \brief This function handles WLAN events

    \param[in]      pWlanEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkWlanEventHandler(SlWlanEvent_t *pWlanEvent) {
    if (pWlanEvent == NULL)
        CLI_Write(" [WLAN EVENT] NULL Pointer Error \n\r");

    switch (pWlanEvent->Event) {
        case SL_WLAN_CONNECT_EVENT: {
            SET_STATUS_BIT(g_Status, STATUS_BIT_CONNECTION);

            /*
             * Information about the connected AP (like name, MAC etc) will be
             * available in 'slWlanConnectAsyncResponse_t' - Applications
             * can use it if required
             *
             * slWlanConnectAsyncResponse_t *pEventData = NULL;
             * pEventData = &pWlanEvent->EventData.STAandP2PModeWlanConnected;
             *
             */
        } break;

        case SL_WLAN_DISCONNECT_EVENT: {
            slWlanConnectAsyncResponse_t *pEventData = NULL;

            CLR_STATUS_BIT(g_Status, STATUS_BIT_CONNECTION);
            CLR_STATUS_BIT(g_Status, STATUS_BIT_IP_ACQUIRED);

            pEventData = &pWlanEvent->EventData.STAandP2PModeDisconnected;

            /* If the user has initiated 'Disconnect' request, 'reason_code' is SL_USER_INITIATED_DISCONNECTION */
            if (SL_USER_INITIATED_DISCONNECTION == pEventData->reason_code) {
                CLI_Write(" Device disconnected from the AP on application's request \n\r");
            } else {
                CLI_Write(" Device disconnected from the AP on an ERROR..!! \n\r");
            }
        } break;

        default: {
            CLI_Write(" [WLAN EVENT] Unexpected event \n\r");
        } break;
    }
}

/*!
    \brief This function handles events for IP address acquisition via DHCP
           indication

    \param[in]      pNetAppEvent is the event passed to the handler

    \return         None

    \note

    \warning
*/
void SimpleLinkNetAppEventHandler(SlNetAppEvent_t *pNetAppEvent) {
    if (pNetAppEvent == NULL)
        CLI_Write(" [NETAPP EVENT] NULL Pointer Error \n\r");

    switch (pNetAppEvent->Event) {
        case SL_NETAPP_IPV4_IPACQUIRED_EVENT: {
            SET_STATUS_BIT(g_Status, STATUS_BIT_IP_ACQUIRED);

            /*
             * Information about the connected AP's IP, gateway, DNS etc
             * will be available in 'SlIpV4AcquiredAsync_t' - Applications
             * can use it if required
             *
             * SlIpV4AcquiredAsync_t *pEventData = NULL;
             * pEventData = &pNetAppEvent->EventData.ipAcquiredV4;
             * <gateway_ip> = pEventData->gateway;
             *
             */
        } break;

        default: {
            CLI_Write(" [NETAPP EVENT] Unexpected event \n\r");
        } break;
    }
}

/*!
    \brief This function handles callback for the HTTP server events

    \param[in]      pHttpEvent - Contains the relevant event information
    \param[in]      pHttpResponse - Should be filled by the user with the
                    relevant response information

    \return         None

    \note

    \warning
*/
void SimpleLinkHttpServerCallback(SlHttpServerEvent_t *pHttpEvent,
                                  SlHttpServerResponse_t *pHttpResponse) {
    /*
     * This application doesn't work with HTTP server - Hence these
     * events are not handled here
     */
    CLI_Write(" [HTTP EVENT] Unexpected event \n\r");
}

/*!
    \brief This function handles general error events indication

    \param[in]      pDevEvent is the event passed to the handler

    \return         None
*/
void SimpleLinkGeneralEventHandler(SlDeviceEvent_t *pDevEvent) {
    /*
     * Most of the general errors are not FATAL are are to be handled
     * appropriately by the application
     */
    CLI_Write(" [GENERAL EVENT] \n\r");
}

/*!
    \brief This function handles socket events indication

    \param[in]      pSock is the event passed to the handler

    \return         None
*/
void SimpleLinkSockEventHandler(SlSockEvent_t *pSock) {
    if (pSock == NULL)
        CLI_Write(" [SOCK EVENT] NULL Pointer Error \n\r");

    switch (pSock->Event) {
        case SL_SOCKET_TX_FAILED_EVENT: {
            /*
             * TX Failed
             *
             * Information about the socket descriptor and status will be
             * available in 'SlSockEventData_t' - Applications can use it if
             * required
             *
             * SlSockEventData_t *pEventData = NULL;
             * pEventData = & pSock->EventData;
             */
            switch (pSock->EventData.status) {
                case SL_ECLOSE:
                    CLI_Write(" [SOCK EVENT] Close socket operation failed to transmit all queued packets\n\r");
                    break;

                default:
                    CLI_Write(" [SOCK EVENT] Unexpected event \n\r");
                    break;
            }
        } break;

        default:
            CLI_Write(" [SOCK EVENT] Unexpected event \n\r");
            break;
    }
}
/*
 * ASYNCHRONOUS EVENT HANDLERS -- End
 */

static void generateUniqueID() {
    CRC32_setSeed(TLV->RANDOM_NUM_1, CRC32_MODE);
    CRC32_set32BitData(TLV->RANDOM_NUM_2);
    CRC32_set32BitData(TLV->RANDOM_NUM_3);
    CRC32_set32BitData(TLV->RANDOM_NUM_4);
    int i;
    for (i = 0; i < 6; i++)
        CRC32_set8BitData(macAddressVal[i], CRC32_MODE);

    uint32_t crcResult = CRC32_getResult(CRC32_MODE);
    sprintf(uniqueID, "%06X", crcResult);
}

//****************************************************************************
//
//!    \brief MQTT message received callback - Called when a subscribed topic
//!                                            receives a message.
//! \param[in]                  data is the data passed to the callback
//!
//! \return                        None
//
//****************************************************************************
static void messageArrived(MessageData *data) {
    CLI_Write("\n Received data \n\r");

    char buf[BUFF_SIZE];

    char *tok;
    long color;

    // Check for buffer overflow
    if (data->topicName->lenstring.len >= BUFF_SIZE) {
        //      UART_PRINT("Topic name too long!\n\r");
        return;
    }
    if (data->message->payloadlen >= BUFF_SIZE) {
        //      UART_PRINT("Payload too long!\n\r");
        return;
    }

    strncpy(buf, data->topicName->lenstring.data,
            min(BUFF_SIZE, data->topicName->lenstring.len));
    buf[data->topicName->lenstring.len] = 0;

    strncpy(buf, data->message->payload,
            min(BUFF_SIZE, data->message->payloadlen));
    buf[data->message->payloadlen] = 0;

    // tok = strtok(buf, " ");
    tok = strtok(buf, " \r\n");

    if (strcmp(tok, "stop") == 0) {
        Mode = 0;
        // Motor_Stop();
        CLI_Write(" Motors Toggled OFF \n\r");
        CLI_Write(tok);

        return;
    } else if (strcmp(tok, "go") == 0) {
        Mode = 1;
        // Motor_Forward(1000,4000);
        CLI_Write(" Motors Toggled ON \n\r");
        CLI_Write(tok);
        return;
    } else if (strcmp(tok, "right") == 0) {
        rightMode = true;
        return;
    } else if (strcmp(tok, "right") == 0) {
        rightMode = false;
        return;
    }

    return;
}

/*
 * Port 1 interrupt handler. This handler is called whenever the switch attached
 * to P1.1 is pressed.
 */
void PORT1_IRQHandler(void) {
    uint32_t status = GPIO_getEnabledInterruptStatus(GPIO_PORT_P1);
    GPIO_clearInterruptFlag(GPIO_PORT_P1, status);

    if (status & GPIO_PIN1) {
        if (S1buttonDebounce == 0) {
            S1buttonDebounce = 1;

            GPIO_setOutputHighOnPin(GPIO_PORT_P1, GPIO_PIN0);

            // Publish the unique ID
            publishID = 1;

            MAP_Timer_A_startCounter(TIMER_A1_BASE, TIMER_A_UP_MODE);
        }
    }
    if (status & GPIO_PIN4) {
        if (S2buttonDebounce == 0) {
            S2buttonDebounce = 1;

            CLI_Write(" MAC Address: \n\r ");
            CLI_Write(macStr);
            CLI_Write("\n\r");

            MAP_Timer_A_startCounter(TIMER_A1_BASE, TIMER_A_UP_MODE);
        }
    }
}

void TA1_0_IRQHandler(void) {
    GPIO_setOutputLowOnPin(GPIO_PORT_P1, GPIO_PIN0);
    if (P1IN & GPIO_PIN1) {
        S1buttonDebounce = 0;
    }
    if (P1IN & GPIO_PIN4) {
        S2buttonDebounce = 0;
    }

    if ((P1IN & GPIO_PIN1) && (P1IN & GPIO_PIN4)) {
        Timer_A_stopTimer(TIMER_A1_BASE);
    }
    MAP_Timer_A_clearCaptureCompareInterrupt(TIMER_A1_BASE,
                                             TIMER_A_CAPTURECOMPARE_REGISTER_0);
}

/*!
    \brief This function configure the SimpleLink device in its default state. It:
           - Sets the mode to STATION
           - Configures connection policy to Auto and AutoSmartConfig
           - Deletes all the stored profiles
           - Enables DHCP
           - Disables Scan policy
           - Sets Tx power to maximum
           - Sets power policy to normal
           - Unregisters mDNS services
           - Remove all filters

    \param[in]      none

    \return         On success, zero is returned. On error, negative is returned
*/
static _i32 configureSimpleLinkToDefaultState() {
    SlVersionFull ver = {0};
    _WlanRxFilterOperationCommandBuff_t RxFilterIdMask = {0};

    _u8 val = 1;
    _u8 configOpt = 0;
    _u8 configLen = 0;
    _u8 power = 0;

    _i32 retVal = -1;
    _i32 mode = -1;

    mode = sl_Start(0, 0, 0);
    ASSERT_ON_ERROR(mode);

    /* If the device is not in station-mode, try configuring it in station-mode */
    if (ROLE_STA != mode) {
        if (ROLE_AP == mode) {
            /* If the device is in AP mode, we need to wait for this event before doing anything */
            while (!IS_IP_ACQUIRED(g_Status)) {
                _SlNonOsMainLoopTask();
            }
        }

        /* Switch to STA role and restart */
        retVal = sl_WlanSetMode(ROLE_STA);
        ASSERT_ON_ERROR(retVal);

        retVal = sl_Stop(SL_STOP_TIMEOUT);
        ASSERT_ON_ERROR(retVal);

        retVal = sl_Start(0, 0, 0);
        ASSERT_ON_ERROR(retVal);

        /* Check if the device is in station again */
        if (ROLE_STA != retVal) {
            /* We don't want to proceed if the device is not coming up in station-mode */
            ASSERT_ON_ERROR(DEVICE_NOT_IN_STATION_MODE);
        }
    }

    /* Get the device's version-information */
    configOpt = SL_DEVICE_GENERAL_VERSION;
    configLen = sizeof(ver);
    retVal = sl_DevGet(SL_DEVICE_GENERAL_CONFIGURATION, &configOpt, &configLen, (_u8 *)(&ver));
    ASSERT_ON_ERROR(retVal);

    /* Set connection policy to Auto + SmartConfig (Device's default connection policy) */
    retVal = sl_WlanPolicySet(SL_POLICY_CONNECTION, SL_CONNECTION_POLICY(1, 0, 0, 0, 1), NULL, 0);
    ASSERT_ON_ERROR(retVal);

    /* Remove all profiles */
    retVal = sl_WlanProfileDel(0xFF);
    ASSERT_ON_ERROR(retVal);

    /*
     * Device in station-mode. Disconnect previous connection if any
     * The function returns 0 if 'Disconnected done', negative number if already disconnected
     * Wait for 'disconnection' event if 0 is returned, Ignore other return-codes
     */
    retVal = sl_WlanDisconnect();
    if (0 == retVal) {
        /* Wait */
        while (IS_CONNECTED(g_Status)) {
            _SlNonOsMainLoopTask();
        }
    }

    /* Enable DHCP client*/
    retVal = sl_NetCfgSet(SL_IPV4_STA_P2P_CL_DHCP_ENABLE, 1, 1, &val);
    ASSERT_ON_ERROR(retVal);

    /* Disable scan */
    configOpt = SL_SCAN_POLICY(0);
    retVal = sl_WlanPolicySet(SL_POLICY_SCAN, configOpt, NULL, 0);
    ASSERT_ON_ERROR(retVal);

    /* Set Tx power level for station mode
       Number between 0-15, as dB offset from max power - 0 will set maximum power */
    power = 0;
    retVal = sl_WlanSet(SL_WLAN_CFG_GENERAL_PARAM_ID, WLAN_GENERAL_PARAM_OPT_STA_TX_POWER, 1, (_u8 *)&power);
    ASSERT_ON_ERROR(retVal);

    /* Set PM policy to normal */
    retVal = sl_WlanPolicySet(SL_POLICY_PM, SL_NORMAL_POLICY, NULL, 0);
    ASSERT_ON_ERROR(retVal);

    /* Unregister mDNS services */
    retVal = sl_NetAppMDNSUnRegisterService(0, 0);
    ASSERT_ON_ERROR(retVal);

    /* Remove  all 64 filters (8*8) */
    pal_Memset(RxFilterIdMask.FilterIdMask, 0xFF, 8);
    retVal = sl_WlanRxFilterSet(SL_REMOVE_RX_FILTER, (_u8 *)&RxFilterIdMask,
                                sizeof(_WlanRxFilterOperationCommandBuff_t));
    ASSERT_ON_ERROR(retVal);

    retVal = sl_Stop(SL_STOP_TIMEOUT);
    ASSERT_ON_ERROR(retVal);

    retVal = initializeAppVariables();
    ASSERT_ON_ERROR(retVal);

    return retVal; /* Success */
}

/*!
    \brief Connecting to a WLAN Access point

    This function connects to the required AP (SSID_NAME).
    The function will return once we are connected and have acquired IP address

    \param[in]  None

    \return     0 on success, negative error-code on error

    \note

    \warning    If the WLAN connection fails or we don't acquire an IP address,
                We will be stuck in this function forever.
*/
static _i32 establishConnectionWithAP() {
    SlSecParams_t secParams = {0};
    _i32 retVal = 0;

    secParams.Key = PASSKEY;
    secParams.KeyLen = PASSKEY_LEN;
    secParams.Type = SEC_TYPE;

    retVal = sl_WlanConnect(SSID_NAME, pal_Strlen(SSID_NAME), 0, &secParams, 0);
    ASSERT_ON_ERROR(retVal);

    /* Wait */
    while ((!IS_CONNECTED(g_Status)) || (!IS_IP_ACQUIRED(g_Status))) {
        _SlNonOsMainLoopTask();
    }

    return SUCCESS;
}

/*!
    \brief This function initializes the application variables

    \param[in]  None

    \return     0 on success, negative error-code on error
*/
static _i32 initializeAppVariables() {
    g_Status = 0;
    pal_Memset(&g_AppData, 0, sizeof(g_AppData));

    return SUCCESS;
}

/*!
    \brief This function displays the application's banner

    \param      None

    \return     None
*/
static void displayBanner() {
    CLI_Write("\n\r\n\r");
    CLI_Write(" MQTT Twitter Controlled RGB LED - Version ");
    CLI_Write(APPLICATION_VERSION);
    CLI_Write("\n\r*******************************************************************************\n\r");
}
