# The follwing directory contains all of the source code and project files for the Wall following robot used in the Race.

- The main.c contains the main source code with all team member code contributions integrated
- The project should be runnable through code composer studio
- The WiFi booster CC3100 module should be attached to the top of the MSP432 microcontroller
